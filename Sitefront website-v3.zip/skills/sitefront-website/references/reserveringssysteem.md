# Reserveringsmodule

Status: NOG AAN TE VULLEN door Michael.

Wat vaststaat:
- De module is gebouwd met Supabase (database) en Resend (bevestigingsmails)
  en draait al bij een bestaande klant.
- De Resend-API-key mag NOOIT in de frontend of de repo staan. Mails gaan
  via de serverkant (bijv. een Supabase Edge Function), want GitHub Pages
  is puur statisch.

Tot dit bestand is aangevuld:
- Bouw de module NIET uit het hoofd.
- Vraag Michael om de bestaande implementatie (repo of code: tabelopzet,
  hoe de mail verstuurd wordt, hoe de klant reserveringen ziet) en hergebruik
  die opzet.
