# Design en tekst

Waarom dit bestaat: een taalmodel valt zonder tegendruk terug op het
gemiddelde van wat het gezien heeft. Het gemiddelde van "moderne website"
is Inter als lettertype, een blauwe knop, afgeronde kaarten met schaduw,
drie kaartjes met iconen en een gecentreerde hero. Dat gemiddelde IS de
AI-look. Deze regels halen dat gemiddelde weg. "Maak het mooi" werkt niet,
concrete verboden wel.

## Design

- Bouw op EIGEN design tokens. Zet in het `@theme` blok
  `--color-*: initial;` zodat het complete standaardpalet van Tailwind
  verdwijnt, en definieer daarna eigen kleuren. Doe hetzelfde voor
  `--text-*`, `--radius-*` en `--shadow-*`. Dan bestaat `bg-blue-500`
  letterlijk niet meer en kun je er niet op terugvallen.
- Een accentkleur, spaarzaam gebruikt. Niet elk element een kleurtje.
- Koppen zwaar en strak: font-weight 800 of 900 met negatieve
  letter-spacing, ongeveer -0.03em. Groot door gewicht, niet door extreme
  afmetingen. (Wijk hier alleen van af als de sfeer van de klant echt iets
  anders vraagt, en benoem dat dan in het plan.)
- Twee lettertypes, meer niet: een display voor koppen, een voor lopende
  tekst. Geen mono voor labels, dat is een designer-tic.
- Kies de lettertypes en kleuren per klant, passend bij de sfeer. Niet
  standaard de fonts van sitefront.nl hergebruiken.
- Niet alles gecentreerd. Werk asymmetrisch. Laat een vlak bewust leeg in
  plaats van het vol te zetten.
- Schaduwen laag en zacht, of helemaal niet.
- Beweging minimaal en met een reden. Twee bewegende dingen op een site
  is genoeg. Alles met CSS, geen animatiebibliotheek.
- Iconen: teken de paar die je echt nodig hebt zelf als SVG. Geen
  compleet iconenpakket.
- Echte foto's van de klant gaan altijd voor. Geen stockfoto's.

## Dit nooit

- Overal afgeronde kaarten met zachte schaduw
- Emoji als icoon
- Glasmorphism, gradient-tekst, gloeiende randen, neon op zwart
- Drie kaartjes naast elkaar met een icoontje erboven en drie regels
  tekst eronder
- Golf- of diagonaaldividers tussen secties
- Stockillustraties, generieke laptopmockups, mensen met headsets
- Een hero met een gecentreerde kop, een emoji en twee knoppen
- UI-bibliotheken: geen shadcn, daisyUI, Flowbite of componenten van
  internet geplukt. Daar komt de sjabloonlook vandaan.

## Tekst

- GEEN em-dashes. Komma's of punten. Dit is de duidelijkste verklikker
  dat een tekst door AI is geschreven.
- Geen "Kortom", "In de wereld van", "Of je nu X bent of Y", "niet
  alleen ... maar ook". Geen drieslagen als opsmuk.
- Korte, directe zinnen. Schrijf zoals een mens praat, niet zoals een
  brochure. Concreet boven abstract: "geen overtypwerk meer" in plaats van
  "efficientere processen".
- Geen generieke koppen als "Welkom bij [naam]" of "Ontdek onze passie".
- Verzin NOOIT feiten, cijfers, ervaringsjaren, testimonials,
  klantnamen of technieken. Gebruik de markering `[[AANLEVEREN: ...]]`.
- Een citaat van een echt persoon komt pas op de site na diens akkoord.

## Kwaliteitseisen

- Mobile-first. Test op 320, 360 en 390 pixels breed, nergens
  horizontaal scrollen.
- Zichtbare focus-outline voor toetsenbordgebruikers.
- Respecteer prefers-reduced-motion.
- Tekstcontrast minimaal 4.5:1, gecontroleerd.
- Een h1 per pagina, koppen slaan geen niveau over.
- Code-commentaar legt uit WAAROM iets zo is, niet wat er staat.

## Houding tijdens het bouwen

- Verzin geen extra secties die niet gevraagd zijn.
- Zeg aan het eind van elke stap eerlijk wat je zelf het zwakst vindt.
- Bij "dit is het niet": kom met een echt andere richting.
