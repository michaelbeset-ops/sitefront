# Stack en deploy

## Programma's en accounts

- Node 24 (of 22 LTS): draait Astro en alle commando's
- Claude Code: bouwen, in de map van het project
- VS Code: bestanden bekijken en kleine dingen zelf aanpassen
- Git + GitHub CLI (`gh`): versiebeheer, repo aanmaken, deploys volgen
- Chrome: testen en screenshots op 1440x900
- Accounts: GitHub (hosting), Web3Forms (formulier), domeinregistrar (DNS)

## Wat wel

- Astro, volledig statisch. Nul JavaScript standaard.
- Tailwind CSS 4 via `@tailwindcss/vite`, alles in CSS met `@theme`,
  geen configbestand.
- Vue 3 via `@astrojs/vue`, alleen als island voor onderdelen die echt
  interactief zijn. De rest is gewone HTML.
- `@astrojs/sitemap` voor sitemap.xml.
- Fonts zelf hosten via `@fontsource-variable/...`, alleen de subsets die
  nodig zijn (latin). Geen verzoek naar Google Fonts.
- `sharp` (zit bij Astro) en Astro's `<Image>` voor bijsnijden en
  comprimeren.
- Lighthouse CLI om echte scores te meten.

## Wat niet

- Geen UI-bibliotheek (shadcn, daisyUI, Flowbite)
- Geen CMS, tenzij de klant echt zelf teksten moet wijzigen. Vraag dat
  dan eerst aan Michael.
- Geen animatiebibliotheek
- Geen compleet iconenpakket

## Opzetten

```bash
npm create astro@latest
npm install @tailwindcss/vite tailwindcss @astrojs/vue vue @astrojs/sitemap
npm install @fontsource-variable/<display-font> @fontsource-variable/<tekst-font>
```

Gebruik de actuele versies. Controleer bij twijfel de Astro- en
Tailwind-docs in plaats van configuratie uit je geheugen te schrijven.

`astro.config.mjs` (kern):

```js
import { defineConfig } from 'astro/config';
import tailwindcss from '@tailwindcss/vite';
import vue from '@astrojs/vue';
import sitemap from '@astrojs/sitemap';

export default defineConfig({
  site: 'https://www.klantdomein.nl', // echte domein, nodig voor sitemap en og-tags
  integrations: [vue(), sitemap()],
  vite: { plugins: [tailwindcss()] },
});
```

Globale CSS (begin):

```css
@import "tailwindcss";

@theme {
  --color-*: initial;   /* standaardpalet weg, zie design-en-tekst.md */
  --text-*: initial;
  --radius-*: initial;
  --shadow-*: initial;

  /* eigen tokens per klant, uit PLAN.md */
  --color-ink: ...;
  --color-paper: ...;
  --color-accent: ...;
  --font-display: "...", ...;
  --font-body: "...", ...;
}
```

## Formulier (Web3Forms)

Gewoon HTML-formulier, geen backend nodig. De access key van Web3Forms is
bedoeld om publiek in de HTML te staan. Voeg een honeypot-veld toe tegen
spam. Het formulier verwerkt persoonsgegevens, dus de privacyverklaring
moet dit noemen. Test het na livegang echt: er moet een mail binnenkomen.

## Screenshots en Lighthouse (voor de zelfreview-lus)

Altijd op de productie-build, niet op de dev-server:

```bash
npm run build && npm run preview   # standaard op http://localhost:4321
```

Screenshots met Playwright (eenmalig `npx playwright install chromium`):

```bash
npx playwright screenshot --full-page --viewport-size=1440,900 http://localhost:4321 shots/home-1440.png
npx playwright screenshot --full-page --viewport-size=390,844  http://localhost:4321 shots/home-390.png
npx playwright screenshot --full-page --viewport-size=320,640  http://localhost:4321 shots/home-320.png
```

Bekijk de afbeeldingen daarna echt. Zet `shots/` in `.gitignore`.

Lighthouse (standaard mobiele emulatie):

```bash
npx lighthouse http://localhost:4321 --quiet --chrome-flags="--headless" --output=json --output-path=shots/lh-home.json
```

Lees de vier categoriescores en de gefaalde audits uit de JSON. Doe dit
voor elke pagina.

## GitHub Pages

1. Repo aanmaken: `gh repo create <naam> --public --source=. --push`.
   Standaard public: GitHub Pages op een private repo werkt alleen met een
   betaald GitHub-abonnement. Wijk alleen af als Michael dat zegt.
2. In de repo: Settings > Pages > Source: **GitHub Actions**
3. Workflow `.github/workflows/deploy.yml` met de officiele Astro-action
   (`withastro/action`) en `actions/deploy-pages`. Neem de actuele
   versie over uit de Astro-deploygids voor GitHub Pages.
4. Custom domein: bestand `public/CNAME` met alleen het domein
   (bijv. `www.klantdomein.nl`). Zonder custom domein en met een
   project-repo is ook `base: '/<repo-naam>'` nodig in de config.
5. DNS bij de registrar: A-records van het kale domein naar de GitHub
   Pages-IP's en een CNAME voor `www` naar `<gebruiker>.github.io`.
   Controleer de actuele IP's in de GitHub-docs.
6. Na DNS-propagatie: "Enforce HTTPS" aanzetten.
7. Volg de deploy met `gh run watch` en controleer daarna de live site.
