# Standaardopbouw en extra vragen per type bedrijf

De standaardopbouw is een VOORSTEL in de intake. Wat Michael bevestigt of
aanpast, wordt gebouwd. Niets meer.

## Horeca (lunchroom, restaurant, cafe)

Standaardopbouw (one-pager of klein aantal pagina's): hero met sfeerbeeld
en reserveer- of belknop, menukaart, over ons, sfeer/galerij, praktisch
(adres, openingstijden, route, contact), footer.

Extra vragen:
- Menukaart: als echte HTML op de site (beter voor mobiel en Google) of
  als PDF-download?
- Reserveren: reserveringsmodule, telefonisch of niet?
- Talen: toeristen in de buurt? (NL/DE/EN komt voor)
- Instagram: feed of alleen een link?
- Afwijkende openingstijden (feestdagen, seizoen)?

## Vakmensen (hovenier, aannemer, installateur)

Standaardopbouw: hero met projectfoto en belknop, diensten, projecten
(swipebare galerij op mobiel), werkgebied, over ons, offerte/contact,
footer. Sticky header met belknop op mobiel.

Extra vragen:
- Projectfoto's, eventueel voor/na?
- Werkgebied: welke plaatsen of regio?
- Offerte via formulier, bellen of WhatsApp?
- Echte reviews beschikbaar (Google, Werkspot)? Nooit zelf verzinnen.

## Bootverhuur en jachthavens

Standaardopbouw: hero met vaarbeeld en reserveerknop, aanbod/vloot met
prijzen, ligplaatsen (jachthaven), vaargebied, praktisch (seizoen,
openingstijden, parkeren, route), contact, footer.

Extra vragen:
- Prijzen per uur/dag/seizoen?
- Reserveren via de module of aanvraagformulier?
- Ligplaatsen: aanvraagformulier of alleen info?

## Overig

Standaardopbouw: hero, wat ze doen, waarom zij, werk of aanbod, over ons,
contact, footer.

Extra vraag: wat is het ene ding waarom klanten voor dit bedrijf kiezen?
Vraag het, verzin het niet.
