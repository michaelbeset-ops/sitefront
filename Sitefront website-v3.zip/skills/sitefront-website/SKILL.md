---
name: "sitefront-website"
description: "Sitefront-werkwijze om met een paar vragen een complete, hoogwaardige website te bouwen met Astro in Claude Code en live te zetten op GitHub Pages, zonder AI-look. Gebruik deze skill ALTIJD wanneer Michael een nieuwe website, landingspagina of losse pagina wil laten bouwen voor een klant of voor Sitefront, een bestaande klantsite wil uitbreiden, verbeteren of opnieuw ontwerpen, demo-sites wil voor bedrijven met een slechte website, of vraagt om een hero, sectie, menukaart, contactformulier, reserveringsmodule of oplevering, ook als hij de woorden \"skill\", \"Sitefront\" of \"Astro\" niet noemt."
---

# Sitefront website bouwen

Dit is de vaste werkwijze van Sitefront (Michael Beset). Er zijn twee modi:

- **Klantmodus** (standaard): Michael activeert de skill, beantwoordt EEN
  blok vragen, keurt de hero goed, en krijgt daarna een complete, geteste
  website die live staat.
- **Demomodus**: Michael vraagt om demo-sites voor bedrijven met een
  slechte website ("zoek zelf bedrijven", "maak demo's", "voorstellen",
  "x websites voor bedrijven met een slechte site"). Jij zoekt de
  bedrijven met de grootste kans om klant te worden, bouwt de sites zonder
  intake en zonder checkpoint, zet ze live in de verzamelrepo en geeft
  Michael de links. Zie het hoofdstuk Demomodus onderaan. Alle design-,
  tekst- en kwaliteitsregels gelden daar net zo hard.

Het werk dat Michael vroeger in rondes met de hand deed (kijken, afkeuren,
opnieuw) doe jij nu zelf: screenshots maken, keihard beoordelen tegen de
regels, meten en verbeteren. Pas als het goed is, laat je het zien.

## Drie regels die boven alles gaan

1. **Verzin nooit inhoud.** Geen feiten, cijfers, ervaringsjaren,
   openingstijden, prijzen, reviews, testimonials of klantnamen.
   Ontbrekend materiaal houdt je niet tegen: bouw door met een markering
   `[[AANLEVEREN: ...]]` (zie onder) en zet het op de lijst.
2. **Vraag alles in een keer, daarna werk je zelfstandig.** Na de intake
   stel je alleen nog een vraag als je anders iets onomkeerbaars of iets
   echt fouts zou doen. Kleine keuzes maak je zelf en noteer je in het
   eindverslag.
3. **Meten, niet beweren.** Elke claim over kwaliteit komt met bewijs:
   een screenshot die je zelf bekeken hebt, een Lighthouse-score of
   commando-uitvoer.

## Het proces (klantmodus)

### Stap 1: Intake (een bericht, dan wachten)

Kijk eerst wat er al is: bestanden in de projectmap (logo, foto's,
menukaart, teksten), wat Michael in zijn bericht gaf, links naar een oude
site of Instagram. Haal daar zoveel mogelijk uit.

Stuur daarna EEN bericht met 5 tot 8 genummerde vragen. Geef bij elke
vraag een voorstel, zodat Michael kan antwoorden met "ok" of alleen de
afwijking. Vraag niets wat je al weet. Vaste onderwerpen:

1. Bedrijf, wat ze doen en voor wie
2. De belangrijkste actie voor een bezoeker (bellen, reserveren, offerte,
   langskomen)
3. Pagina's en secties. Stel de standaardopbouw voor uit
   references/branches.md, passend bij het type bedrijf.
4. Sfeer en toon, plus voorbeeldsites als maatstaf (optioneel)
5. Praktische gegevens: adres, telefoon, e-mail, openingstijden,
   KvK-nummer (of: "laat ik open met markeringen")
6. Domein (en of de DNS al klaar kan worden gezet)
7. Extra's: reserveringsmodule, meerdere talen, embeds zoals Google Maps
   of Instagram (bepaalt de cookiemelding)

Voeg de branchevragen uit references/branches.md toe als ze relevant zijn,
maar blijf binnen de 8 vragen door ze samen te voegen.

Na het antwoord bepaal je zelf de designrichting (fonts, kleuren,
compositie) en begin je te bouwen. Geen apart plan ter goedkeuring.
Schrijf je keuzes wel kort in `PLAN.md` in de projectmap, als naslag.

### Stap 2: Opzetten

Volg references/stack-en-deploy.md. Lees references/design-en-tekst.md
voordat je de eerste regel markup of tekst schrijft. Zet eerst het
`@theme` blok met eigen design tokens neer, pas daarna componenten.

### Stap 3: Hero bouwen, zelf beoordelen, dan het enige checkpoint

Bouw de hero. Draai daarna de zelfreview-lus (zie onder) tot de hero door
alle controles komt. Laat Michael dan zien:

- screenshot desktop (1440x900) en mobiel (390 breed)
- in twee zinnen de gekozen richting (fonts, kleuren, idee)
- wat je zelf het zwakst vindt

Stop en wacht op zijn reactie. Dit is het enige checkpoint. Zegt hij "nee,
dit is het niet", kom dan met een ECHT andere richting (andere compositie,
andere typografie), geen kleine variatie.

Michael kan HTML-bestanden niet goed bekijken in de chat: laat altijd
PNG-screenshots zien, geen losse HTML.

### Stap 4: De rest van de site in een keer

Na akkoord op de hero bouw je alle pagina's en secties uit de intake af,
inclusief formulier, privacyverklaring en cookiemelding. Verzin geen
secties die niet zijn afgesproken. Draai na elke pagina de zelfreview-lus.

### Stap 5: Eindcontrole

Loop de opleveringschecklist (onder) af op de productie-build. Repareer
wat faalt en controleer opnieuw.

### Stap 6: Live zetten

Deploy naar GitHub Pages volgens references/stack-en-deploy.md.

- Staan er nog `[[AANLEVEREN` markeringen in `src/`? Zet de site dan
  alleen live op het `github.io`-adres als preview, NIET op het domein van
  de klant. Een klant mag nooit een site met gaten op zijn eigen domein
  zien staan.
- Is alles compleet? Koppel dan het custom domein. DNS-records bij de
  registrar kan Michael alleen zelf zetten: geef hem exact wat hij moet
  invullen.

### Stap 7: Eindverslag

Een kort verslag aan Michael, in deze vorm:

```
LIVE: <url>  (preview of definitief)
LIGHTHOUSE MOBIEL: performance x / toegankelijkheid x / best practices x / SEO x
CHECKLIST: alles groen, of welke punten niet en waarom
ZELF GEKOZEN: de keuzes die je zonder te vragen hebt gemaakt
ZWAKSTE PUNT: wat je zelf nog het minst goed vindt
NOG AANLEVEREN: lijst van alle [[AANLEVEREN]] markeringen
ACTIE VOOR MICHAEL: bijv. DNS-records, Web3Forms-key, klant om foto's vragen
```

## De zelfreview-lus

Dit vervangt de rondes die Michael anders met de hand zou doen. Neem hem
serieus: een eerste versie is bijna nooit goed genoeg.

1. Draai een productie-build met preview (`npm run build && npm run preview`).
2. Maak screenshots op 1440, 390 en 320 breed (full page), zie
   references/stack-en-deploy.md. BEKIJK ze echt.
3. Beoordeel elke screenshot tegen references/design-en-tekst.md. Schrijf
   voor jezelf op wat er mis is. Stel jezelf deze vragen:
   - Zou iemand dit herkennen als AI-werk of een template? Waaraan?
   - Staat er iets uit de "Dit nooit"-lijst op?
   - Is alles gecentreerd of heeft elke sectie hetzelfde ritme?
   - Hoe breken de koppen op 320 en 390? Te veel regels?
   - Klopt de hierarchie: ziet een bezoeker binnen 3 seconden wat het
     bedrijf doet en wat hij moet doen?
   - Leest de tekst als een mens, of als een brochure?
4. Repareer alles wat je vond.
5. Herhaal. Maximaal 3 rondes per onderdeel. Is het daarna nog niet goed,
   meld dan eerlijk wat er blijft schuren in plaats van eindeloos te
   blijven schuiven.

## Markering voor ontbrekend materiaal

Gebruik overal dezelfde markering: `[[AANLEVEREN: korte omschrijving]]`,
bijvoorbeeld `[[AANLEVEREN: openingstijden]]` of
`[[AANLEVEREN: foto interieur, liggend]]`. Voor foto's: een rustig vlak in
de huisstijlkleur met de markering erin, geen stockfoto. Citaten of reviews
van echte personen staan achter `[[AANLEVEREN: akkoord citaat van ...]]`
tot diegene akkoord heeft gegeven.

Vinden: `grep -rn "AANLEVEREN" src/`

## Opleveringschecklist

- [ ] Geen standaard Tailwind-kleurklassen:
      `grep -rnE "(bg|text|border|ring|fill|stroke|from|to|via)-(slate|gray|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose)-[0-9]{2,3}" src/`
      geeft niets
- [ ] Geen em-dashes in de zichtbare tekst: `grep -rn "—" src/` geeft niets
- [ ] Lighthouse mobiel: 100 op alle vier de onderdelen (of eerlijk
      gemeld waarom niet)
- [ ] Geen horizontale scroll op 320 pixels
- [ ] Alle interne links en ankers werken
- [ ] Een h1 per pagina, geen overgeslagen kopniveaus
- [ ] Zichtbare focus-outline, prefers-reduced-motion gerespecteerd
- [ ] sitemap.xml, robots.txt, og-afbeelding, meta description en JSON-LD
      (alleen met echte gegevens; in demomodus GEEN JSON-LD en geen canonical)
- [ ] Juiste `lang` op de html-tag
- [ ] Privacyverklaring met de gegevens van de klant
- [ ] Cookiemelding volgens Sitefront-standaard, afgestemd op wat er echt
      geplaatst wordt (embeds, analytics). Plaatst de site niets, dan geen
      banner en dat staat in de privacyverklaring.
- [ ] Contactformulier werkt (na livegang: testbericht komt binnen). In
      demomodus staat het formulier uit.
- [ ] Geen verzonnen feiten, cijfers of citaten
- [ ] `[[AANLEVEREN` leeg, of site staat alleen als preview live

## Demomodus: demo-sites voor bedrijven met een slechte website

Doel: Michael laat je zelfstandig werken en krijgt aan het eind een lijst
met live links (per bedrijf een map in de verzamelrepo) plus bewijs van
hoe slecht de oude site is. Die links gebruikt hij voor zijn verkoop.

Het belangrijkste in deze modus is de KEUZE van het bedrijf. Een mooie
demo voor een bedrijf dat toch niet koopt is verspilde tijd. Liever drie
bedrijven met 9/10 kans dan vijf met 6/10. Wees streng en nauwkeurig.

### Wat anders is dan klantmodus

- GEEN intake en GEEN hero-checkpoint. Vraag vooraf alleen wat Michael
  niet al zei: hoeveel bedrijven, welke regio, welke branches. Daarna
  werk je alles zelf af. De zelfreview-lus en de opleveringschecklist
  draai je wel volledig, per site.
- Alle inhoud komt van de eigen openbare bronnen van het bedrijf (hun
  huidige site, Google-profiel, Facebook, Instagram). Niets verzinnen. Wat
  ontbreekt wordt `[[AANLEVEREN: ...]]`.
- Foto's: geen stockfoto's. Hun eigen foto's zijn meestal te klein;
  gebruik dan een vlak met `[[AANLEVEREN]]`.

### Stap D1: Bedrijven zoeken en scoren

Zoeken:

- Zoek met WebSearch op regio plus branche. Bekijk kandidaten in de
  ingebouwde browser (Claude_Browser): de cloudomgeving kan de meeste
  bedrijfssites niet direct bereiken, WebFetch geeft alleen tekst.
- Bekijk per kandidaat de huidige site EN minstens een tweede bron
  (Google-profiel, Facebook of Instagram) om actief-zijn en ambitie te
  beoordelen.

Harde eisen (alle drie, anders valt het bedrijf af):

1. **De site is echt slecht**, vastgesteld in de browser (bijv. via
   javascript: doctype, viewport-meta, frames, scrollWidth op mobiel).
   Minstens twee hiervan: frames of tabellen als layout, geen
   viewport-meta, horizontaal scrollen op 390 breed, geen https,
   gedateerde look (felle achtergrond, GIF-knoppen, Flash-resten),
   standaardinhoud van een sitebouwer ("Hello world", lorem ipsum),
   essentiele info (openingstijden, adres, telefoon) ontbreekt op de
   homepage.
2. **Een 06-nummer** op de site of het Google-profiel. Dat betekent
   meestal een eigenaar die zelf de telefoon opneemt en zelf beslist.
   Uitzondering alleen bij een score van 10/10 op de rest ("hele
   potentiele site") en een direct contact met de eigenaar (naam plus
   e-mail); noem die uitzondering dan expliciet in het verslag.
3. **Het bedrijf is aantoonbaar actief**: recente Google-reviews of
   social posts (laatste 3 maanden), niet "tijdelijk" of "permanent
   gesloten", geen opheffingsuitverkoop.

Kansscore (0 tot 10), alleen bedrijven met 9 of 10 gaan door:

| Punten | Criterium |
|---|---|
| 2 | Harde eisen gehaald (verplicht) |
| 2 | Het bedrijf heeft er echt iets aan: klanten zoeken ze online en haken nu af (horeca, vakmensen, winkels met aanloop; openingstijden, menu, offerte of route ontbreken of zijn onbruikbaar op mobiel) |
| 2 | Eigenaar-gerund en zelfstandig: geen keten, franchise of groter bedrijf met een eigen marketingafdeling |
| 1 | Ambitie of investering zichtbaar: actieve Instagram/Facebook, verbouwing, nieuwe producten, uitbreiding |
| 1 | Goede reputatie: Google-score 4,3 of hoger met een redelijk aantal reviews (een nieuwe site levert dan direct meer op) |
| 1 | Geen recente vernieuwing of lopend traject zichtbaar (geen "binnenkort nieuwe website", geen bureau-credit van dit jaar) |
| 1 | Past bij Sitefront: regio Drechtsteden of omgeving, branche waar Sitefront al klanten heeft (horeca, vakmensen, winkels) |

Afvallers, altijd: ketens en franchises, bedrijven die al klant of lead
zijn van Sitefront, sites die alleen "niet mooi" zijn maar wel goed werken
op mobiel, bedrijven die alleen via een platform verkopen (bijv. alleen
Thuisbezorgd) en daar tevreden mee lijken.

Twijfel je over een punt, geef het dan NIET. Vind je minder bedrijven met
9/10 dan gevraagd, lever dan minder en zeg eerlijk waarom, in plaats van
de lat te verlagen.

Leg per gekozen bedrijf vast: naam, adres, 06-nummer, URL oude site, de
score per criterium met bewijs (wat je zag en waar), en twee screenshots
van de oude site (desktop en mobiel, via `save_to_disk`). Haal daarna alle
echte inhoud op (alle pagina's: over, diensten, contact, openingstijden,
KvK als die er staat).

### Stap D2: Bouwen

Per bedrijf een eigen Astro-project, volgens klantmodus stap 2 t/m 5,
zonder checkpoint. Elke site krijgt een eigen designrichting die bij het
bedrijf past: nooit twee demo's met dezelfde fonts, kleuren of compositie.

Demo-specifiek, altijd:

- Bouw met omgevingsvariabele `PUBLIC_VOORSTEL=1`. In die modus:
  - bovenaan een balk: "Ontwerpvoorstel van Sitefront voor <bedrijf>. Dit
    is niet de officiele website." met link naar https://www.sitefront.nl
  - `<meta name="robots" content="noindex, nofollow">`
  - geen JSON-LD en geen canonical naar het domein van het bedrijf
  - het contactformulier verstuurt niets: geen submit-knop, wel de
    melding dat men het bedrijf rechtstreeks kan mailen of bellen
- `astro.config.mjs`: `site: 'https://michaelbeset-ops.github.io'` en
  `base: '/sitefront/<slug>'`. Alle interne links en assets via
  `import.meta.env.BASE_URL`, zodat ze in de submap werken.
- Slug: naam in kleine letters met streepjes, bijv. `de-2-uiltjes`,
  `bakkerij-van-dijk`.

### Stap D3: Live zetten in de verzamelrepo

- Verzamelrepo: `michaelbeset-ops/sitefront` (public). GitHub Pages staat
  op "Deploy from a branch", main, / (root). De sessie moet met deze repo
  gestart zijn; zonder toegang: niet omheen werken, maar Michael vragen
  een nieuwe sessie te starten met `sitefront` geselecteerd.
- Structuur in de repo:
  ```
  .nojekyll            verplicht, anders slaat Pages de map _astro over
  README.md            tabel: bedrijf | link | kansscore | datum | status
  <slug>/              de gebouwde site (inhoud van dist/)
  bron/<slug>/         de Astro-broncode, zonder node_modules en dist
  ```
- Clone de repo, kopieer `dist/` naar `<slug>/`, de broncode naar
  `bron/<slug>/`, werk de README-tabel bij, commit en push naar main.
- Wacht 1 tot 2 minuten en controleer de live link in de ingebouwde
  browser (github.io is vanuit de cloudomgeving niet bereikbaar): pagina
  laadt, fonts en opmaak kloppen, privacylink en ankers werken, balk staat
  bovenaan. Pas daarna telt de site als live.
- Wordt een demo-bedrijf klant: de site gaat naar een eigen repo en het
  eigen domein volgens klantmodus stap 6, en de demo-map wordt verwijderd.

### Stap D4: Eindverslag demomodus

Een overzicht, in deze vorm, en de screenshots (oud en nieuw, PNG/JPG)
als bijlage:

```
BATCH: <aantal> demo's, <datum>

1. <Bedrijf>, <plaats>, 06-nummer
   LIVE: https://michaelbeset-ops.github.io/sitefront/<slug>/
   KANSSCORE: 9/10 (per criterium: waarom, met bewijs)
   OUDE SITE: <url>. Mis: <concreet, bijv. frames, horizontaal scrollen op mobiel>
   WAAROM ZE ERAAN VERDIENEN: <concreet: wat een nieuwe site hen oplevert>
   LIGHTHOUSE MOBIEL: x / x / x / x
   ZWAKSTE PUNT: ...
   NOG AANLEVEREN: ...

2. ...

AFGEVALLEN: korte lijst van bekeken bedrijven die net niet haalden en waarom
ACTIE VOOR MICHAEL: bedrijven bellen (hoogste score eerst); bij interesse foto's en logo vragen.
```

## Referentiebestanden

- `references/design-en-tekst.md`: designregels, verboden patronen,
  schrijfregels. Lees voor je begint met bouwen.
- `references/stack-en-deploy.md`: installatie, tokens, fonts, formulier,
  screenshots, Lighthouse, GitHub Pages.
- `references/branches.md`: standaardopbouw en extra vragen per type
  bedrijf. Lees bij de intake, en in demomodus bij het kiezen van de
  opbouw.
- `references/reserveringssysteem.md`: alleen lezen als er een
  reservering nodig is.